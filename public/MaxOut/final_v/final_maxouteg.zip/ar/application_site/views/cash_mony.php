<?php

ob_start();
if(!isset($_SESSION['username_admin'])||$_SESSION['username_admin']==""){
header("Location:http://maxouteg.com/new/"); 
}
else{
 $username_admin=$_SESSION['username_admin'];
 $id_useradmin=$_SESSION['id_useradmin'];
}

$success="رسالة النجاح! إعدادات تم حفظها في قاعدة البيانات";
$error="رسالة خطأ! كان هناك خطأ في البيانات المدرجة، أو أن هناك بيانات ناقصة";
if(isset($mess_s)){
$df="block";
}
else{
$df="none";	
}
foreach($info as $row){ 
	$cash=$row->cash;
		$id_cat=$row->id;				
?>

<?php }?>
<!DOCTYPE html>



<!--[if !IE]><!--><html class="sidebar sidebar-discover"><!-- <![endif]-->

<head>

	<title>اعدادت الرصيد</title>



	<meta charset="utf-8">
<?php 
include ("home/inc/head2.inc");
	?>
<script src="assets/js/jquery-1.9.1.min.js"></script>
</head>
<body class="">
	<!-- Main Container Fluid -->

	<div class="container-fluid menu-hidden">
<?php 

include ("home/inc/sidebar2.inc");

?>

		</div>

		<!-- // Sidebar Menu END -->

				

		<!-- Content -->

		<div id="content">



<?php 
include("home/inc/header.inc");
?>		
<div class="innerLR">

	<!-- Widget -->
	<div class="widget-body innerAll">
<div class="n_ok" style="display:<?php echo $df;?>; direction:rtl; font-family:NeoSansArabic !important"><p><?php echo $success?></p></div>
                <div class="n_error" style="display:none"><p><?php echo $error?></p></div>
				<div class="innerLR">
	<!-- Form -->
<form  method="post" action="../update_cash" id="myform">
<input type="hidden" name="id" value="<?php echo $id_cat; ?>"
	<!-- Widget -->
	<div class="widget">

<div class="widget-body innerAll inner-2x">
		
			<!-- Row -->
			<div class="row innerLR"  >
			
				<!-- Column -->
				<div class="col-md-4" style="width:100%; direction:rtl" align="center" >
					<div class="form-group">
					<label class="control-label" for="firstname" style=" direction:rtl; float:right;font-family:NeoSansArabic !important">قيمة الرصيد الحالى</label>
                        <input class="form-control" id="firstname" name="cash"  value="<?php echo $cash?>" type="text" readonly style="width:100%"/>
	
				</div></div>
                <div class="col-md-4" style="width:100%; direction:rtl" align="center" >
					<div class="form-group">
					<label class="control-label" for="firstname" style=" direction:rtl; float:right;font-family:NeoSansArabic !important">القيمة المضافة</label>
                        <input class="form-control" id="firstname" name="new_cash"  type="text"style="width:100%"/>
	
				</div></div>
                
                                <div class="col-md-4" style="width:100%; direction:rtl" align="center" >
					<div class="form-group">
					<label class="control-label" for="firstname" style=" direction:rtl; float:right;font-family:NeoSansArabic !important">نوع العملية</label>
                   <span style="margin-left:40px">    <input type="radio" value="1" name="type"><span style="font-family:NeoSansArabic !important;margin-right:5px;">اضاف الى الحساب</span></span>
                        <input type="radio" value="0" name="type"><span style="font-family:NeoSansArabic !important; margin-right:5px;">حذف من الحساب</span>
	
				</div></div>

			<!-- Form actions -->
			<div class="form-actions" align="center">
             <input type="submit" value="حفظ الاعدادت" class="btn btn-primary fa fa-check-circle" id="Send"  style="font-family:NeoSansArabic !important">
			</div>
			<!-- // Form actions END -->
			
		</div>
	</div>
	<!-- // Widget END -->
	
</form>
<!-- // Form END -->			</div>
			
			
		</div>

	
	
		
		</div>





		<div class="clearfix"></div>
<div id="footer" class="hidden-print">

			<?php

            include ("home/inc/footer.inc");

			?>

		

		</div>

		

		<!-- // Footer END -->

		

	</div>

	<!-- // Main Container Fluid END -->

	<?php

    include ("home/inc/headf2.inc");

	?>
</body>
</html>