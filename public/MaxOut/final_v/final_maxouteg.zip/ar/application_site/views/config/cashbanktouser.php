<?php
ob_start();
 $dd=base_url();
include('opendb.inc');
$username=$_POST['username'];
$usercode=$_POST['usercode'];
$cash=$_POST['cash'];
$pincode=$_POST['pincode'];
$id=$_POST['id'];
echo $cash;

$sqlcash="select id from client where username='$username' ";
$resdcash=mysql_query($sqlcash);
$rowcash=mysql_fetch_array($resdcash);
$id_sender=$rowcash['id'];


$sqlcash="select SUM(cash_money) as cash_money from cash_type where customer_id='$id' and type='get' and view='1' ";
$resdcash=mysql_query($sqlcash);
$rowcash=mysql_fetch_array($resdcash);
$cashmoney_get=$rowcash['cash_money'];
//echo $cashmoney_get;

$sqlpost="select SUM(cash_money) as cash_money from cash_type where customer_id='$id' and type='post' and view='1' ";
$resdpost=mysql_query($sqlpost);
$rowpost=mysql_fetch_array($resdpost);
$cashmoney_post=$rowpost['cash_money'];
$total_cash=$cashmoney_get-$cashmoney_post;

echo $total_cash;
if($total_cash>$cash){


$sql = "INSERT INTO cash_type 
(cash_money,customer_id,comtiontype,client_sender,type,view)
 VALUES('$cash','$id','transfer ','$id_sender','post','1')";
$rsd= mysql_query($sql) or die(mysql_error());


$sql = "INSERT INTO cash_type 
(cash_money,customer_id,comtiontype,client_sender,type,view)
 VALUES('$cash','$id_sender','transfer ','$id','get','1')";
$rsd= mysql_query($sql) or die(mysql_error());
header("location:cash_to_user?success");
}
else {
header("location:cash_to_user?error");
}

include('closedb.inc');
//
ob_flush();
?>
