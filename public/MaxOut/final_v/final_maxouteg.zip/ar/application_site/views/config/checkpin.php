<?php
ob_start();
include('opendb.inc');
$pincode=$_POST['pincode'];
$id_useradmin=$_POST['id_useradmin'];
$coun=mysql_num_rows(mysql_query("select * from client where pincode='$pincode' and id='$id_useradmin'"));
if($coun==1){
$exist='1';
}
else{
$exist='0';	
}
echo json_encode($coun);
include('closedb.inc');
ob_flush();
?>
