<?php
ob_start();
include('opendb.inc');
$pincode=$_POST['pincode'];
$banknumber=$_POST['banknumber'];
$bankowner=$_POST['bankowner'];
$cash=$_POST['cash'];
$id_useradmin=$_POST['id'];
$sql="select * from client where pincode='$pincode' and id='$id_useradmin'";
$resd=mysql_query($sql) or die("".mysql_error());

$counss=mysql_num_rows(mysql_query($sql));
if($counss==1&&$cash>0&&$banknumber!=""){
$exist='1';
}
else{
$exist='0';	
}
echo json_encode($exist);
include('closedb.inc');
ob_flush();
?>
