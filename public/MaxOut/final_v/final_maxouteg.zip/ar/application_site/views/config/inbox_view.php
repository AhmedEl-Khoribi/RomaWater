<?php
ob_start();
include("opendb.inc");
$id=$_GET['message'];
$messagetype=$_GET['messagetype'];

echo $messagetype;
$sql = "UPDATE  client_message SET  view='0' WHERE id = '$id'";
$rsd = mysql_query($sql) or die(mysql_error());

include('closedb.inc');
if($messagetype==="send"){
	header("location:http://localhost/mywork/maxout/maxout_cpanel/home/send");
}
elseif($messagetype==="inbox"){
	header("location:http://localhost/mywork/maxout/maxout_cpanel/home/inbox");
}
elseif($messagetype="myinbox"){
	header("location:http://localhost/mywork/maxout/maxout_cpanel/home/myinbox");
}
ob_flush();
?>
