 <?php
if(!isset($_SESSION['username_admin'])||$_SESSION['username_admin']==""){
header("Location:http://maxouteg.com/new/"); 
}
else{
 $username_admin=$_SESSION['username_admin'];
 $id_useradmin=$_SESSION['id_useradmin'];
}
if(isset($_GET['up'])){
	$showw="block";
	}
	else{
	$showw="none";	
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Account | MaxOut</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <?php include("home/inc/head2.inc");?>
    </head><!--/head-->
   
<?php
include("config/opendb.inc");
$sql="select logo from site_info";
$resd=mysql_query($sql);
$row=mysql_fetch_array($resd);
$img=$row['logo'];


$sqlc="select activation from client where id='$id_useradmin'";
$resdc=mysql_query($sqlc);
$rowc=mysql_fetch_array($resdc);
$activation_code=$rowc['activation'];

foreach($netinfo as $row)
$active_account=$row->active_account;
$price_activeaccount=$row->price_activeaccount;
if($active_account==1&&$activation_code==0){
	$show="block";
	}
	else {
		$show="none";
		}
		


$sqlcash="select SUM(cash_money) as cash_money from cash_type where customer_id='$id_useradmin' and type='get' and view='1' ";
$resdcash=mysql_query($sqlcash);
$rowcash=mysql_fetch_array($resdcash);
$cashmoney_get=$rowcash['cash_money'];
//echo $cashmoney_get;

$sqlpost="select SUM(cash_money) as cash_money from cash_type where customer_id='$id_useradmin' and type='post' and view='1' ";
$resdpost=mysql_query($sqlpost);
$rowpost=mysql_fetch_array($resdpost);
$cashmoney_post=$rowpost['cash_money'];
$total_cash=$cashmoney_get-$cashmoney_post;

?>

</head><!--/head-->

<body>
	<?php include("home/inc/header.inc");?><!--/header-->

	<section>
		<div class="container">
			<div class="row">
				
								<div class="col-sm-3">
					<div class="left-sidebar">
                        <div class="shipping text-center"><!--user-profile-->
                            <h2 class="username"><?php echo $username_admin?></h2>
                             <img src="<?php echo base_url()?><?php echo $image_client?>" alt="" />
                            <script type="text/javascript">
                            function performClick(elemId) {
                               var elem = document.getElementById(elemId);
                               if(elem && document.createEvent) {
                                  var evt = document.createEvent("MouseEvents");
                                  evt.initEvent("click", true, false);
                                  elem.dispatchEvent(evt);
                               }
                            }
                            </script>
                            <a href="#" onclick="performClick('theFile');" class="change-img" title="Change Picture"><i class="fa fa-camera" aria-hidden="true"></i></a>
                            <input type="file" id="theFile" style="display:none;"/>
						</div><!--/user-profile-->


						<h2>FAVOURITES</h2>
						<!--/user-favourites-->

<?php include("home/inc/favorite.inc");?>

					</div>
				</div>

				<div class="col-sm-9 padding-right">
					<div class="features_items"><!--features_items-->
						<h2 class="title text-center">Registration Deposit Data</h2>

                        <div class="col-sm-12">
							<div class="cash-bank account">
                                <h4>Cash Bank : <span><?php echo $total_cash;?></span></h4>
                                <h4 style="font-size:16px; display:<?php echo $showw?>">The Transfer Cash has been successfully</h4>
                                                               

                        		<form action="deposit_action" method="post">
                                 <input type="hidden" value="<?php echo $id_useradmin?>" name="id" >
                                    <div class="form-item">
                                      <label>Bank Name:</label>
                        			<select  name="bankname" id="bank_name">
                                    <option value="0">Select Bank Name</option>
                                    <?php 
									$sql="select * from bank_account where type='حساب بنك' order by id desc";
									$ress=mysql_query($sql);
									while($rows=mysql_fetch_array($ress)){
									?>
                                        <option value="<?php echo $rows['id']?>"><?php echo $rows['name']?></option>
                                        <?php }?>
                                       
                                    </select>
                                    </div>
                                         <div class="form-item" style="display: none" id="account_number">
                                        <label>Account Number:</label>
                                        <input type="text"  name="account_number" id="acc_num" readonly/>
                                    </div>
                                    
                                    <div class="form-item">
                                        <label>Branch:</label>
                                        <input type="text" required placeholder="Branch" name="branch"/>
                                    </div>
                                    <div class="form-item">
                                        <label>Depositor name:</label>
                                        <input type="text" required placehol der="Depositor name" name="depositor"/>
                                    </div>
                                    <div class="form-item">
                                        <label>Serial number:</label>
                                        <input type="text" required placeholder="Serial number" name="serial_num"/>
                                    </div>
                                    <div class="form-item">
                                        <label>Cash Amount:</label>
                                        <input type="text" placeholder="Cash Amount" required name="cash"/>
                                    </div>
                                    <div class="form-item">
                                        <label>Phone:</label>
                                        <input type="text" required placeholder="Phone" name="phone"/>
                                    </div>
                                    <div class="form-item">
                                        <label>Transfer Date:</label>
                                        <input type="datetime" placeholder="Transfer Date" class="datepicker" name="date"/>
                                    </div>
                                    <div class="form-item">
                                        <label>National ID:</label>
                                        <input type="text" required placeholder="National ID" name="nationalid"/>
                                    </div>
                                    <div class="form-item">
                                        <label>City:</label>
                                         <input type="text" required placeholder="City"  name="city"/>
                                    </div>
                                    <div class="form-item">
                                        <label>Address:</label>
                                        <input type="text" required placeholder="Address" name="address"/>
                                    </div>
                                    <div class="form-item">
                                        <label>Pincode:</label>
                                        <input type="text" required placeholder="Pincode" name="pincode"/>
                                    </div>
                                   <!-- <div class="form-item">
                                        <input type="checkbox"/>
                                        <span>jklagsdujgajkltsjhgafhastfjghksafthjsaf</span>
                                    </div>
                                    <div class="form-item">
                                        <input type="checkbox"/>
                                        <span>jklagsdujgajkltsjhgafhastfjghksafthjsaf</span>
                                    </div>
                                    <div class="form-item">
                                        <input type="checkbox" />
                                        <span>jklagsdujgajkltsjhgafhastfjghksafthjsaf</span>
                                    </div>----->
                                    <button type="submit" class="btn">Save Data</button>
                        		</form>

 
                <div class="sep"></div>
              


							</div>
						</div>
						
					</div><!--features_items-->


				</div>
			</div>
		</div>
	</section>
	
	<footer id="footer"><!--Footer-->
		<div class="footer-top">
			<div class="container">
				<div class="row">
					<div class="col-sm-2">
						<div class="companyinfo">
							<h2><span>MAX</span>OUT</h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit,sed do eiusmod tempor</p>
						</div>
					</div>
					<div class="col-sm-7">
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="../home/images/home/iframe1.png" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								<p>Circle of Hands</p>
								<h2>24 DEC 2014</h2>
							</div>
						</div>
						
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="../home/images/home/iframe2.png" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								<p>Circle of Hands</p>
								<h2>24 DEC 2014</h2>
							</div>
						</div>
						
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="../home/images/home/iframe3.png" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								<p>Circle of Hands</p>
								<h2>24 DEC 2014</h2>
							</div>
						</div>
						
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="../home/images/home/iframe4.png" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								<p>Circle of Hands</p>
								<h2>24 DEC 2014</h2>
							</div>
						</div>
					</div>
					<div class="col-sm-3">
						<div class="address">
							<img src="../images/home/map.png" alt="" />
							<p>505 S Atlantic Ave Virginia Beach, VA(Virginia)</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="footer-widget">
			<div class="container">
				<div class="row">
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>Service</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="#">Online Help</a></li>
								<li><a href="#">Contact Us</a></li>
								<li><a href="#">Order Status</a></li>
								<li><a href="#">Change Location</a></li>
								<li><a href="#">FAQ’s</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>Quock Shop</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="#">T-Shirt</a></li>
								<li><a href="#">Mens</a></li>
								<li><a href="#">Womens</a></li>
								<li><a href="#">Gift Cards</a></li>
								<li><a href="#">Shoes</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>Policies</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="#">Terms of Use</a></li>
								<li><a href="#">Privecy Policy</a></li>
								<li><a href="#">Refund Policy</a></li>
								<li><a href="#">Billing System</a></li>
								<li><a href="#">Ticket System</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>About Shopper</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="#">Company Information</a></li>
								<li><a href="#">Careers</a></li>
								<li><a href="#">Store Location</a></li>
								<li><a href="#">Affillate Program</a></li>
								<li><a href="#">Copyright</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-3 col-sm-offset-1">
						<div class="single-widget">
							<h2>About Shopper</h2>
							<form action="#" class="searchform">
								<input type="text" placeholder="Your email address" />
								<button type="submit" class="btn btn-default"><i class="fa fa-arrow-circle-o-right"></i></button>
								<p>Get the most recent updates from <br />our site and be updated your self...</p>
							</form>
						</div>
					</div>
					
				</div>
			</div>
		</div>
		
		<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<p class="pull-left">Copyright © 2016 MaxOut. All rights reserved.</p>
					<p class="pull-right">Designed by <span><a target="_blank" href="http://www.tech4life.com">Tech4Life</a></span></p>
				</div>
			</div>
		</div>
		
	</footer><!--/Footer-->
	
<?php include("home/inc/headf2.inc");?>

<script type="text/javascript">
$(document).ready(function(e) {    
$('#usercode').click(function(e){
	    $(".n_error").hide();
		e.preventDefault();
		var username=$("#username").val();
		var data={username:username};
    $.ajax({
        url: 'checkusername',
        type: 'POST',
        dataType: 'json',
        data:data,
        success: function( data ) {
			//alert(data);
            if(data==1){
				$(".n_seccs").show();
				$(".n_error0").hide();	
		     // $('#form').unbind('submit').submit();//renable submit
			}else{
				$(".n_error0").show();
				$(".n_seccs").hide();							
			}
        }
    });
});
});
</script>



<script type="text/javascript">
$(document).ready(function(e) {    
$('#cash').click(function(e){
	    $(".n_error").hide();
		e.preventDefault();
		var usercode=$("#usercode").val();
		var data={usercode:usercode};
    $.ajax({
        url: 'checkusercode',
        type: 'POST',
        dataType: 'json',
        data:data,
        success: function( data ) {
			//alert(data);
            if(data==1){
				$(".n_seccs").show();
				$(".n_error1").hide();	
		      //$('#form').unbind('submit').submit();//renable submit
			}else{
				$(".n_error1").show();
				$(".n_seccs").hide();							
			}
        }
    });
});
});
</script>


<script type="text/javascript">
$(document).ready(function(e) {    
$('#btn').click(function(e){
	    $(".n_error").hide();
		e.preventDefault();
		var pincode=$("#pincode").val();
		var data={pincode:pincode};
    $.ajax({
        url: 'checkpincode',
        type: 'POST',
        dataType: 'json',
        data:data,
        success: function( data ) {
			//alert(data);
            if(data==1){
				$(".n_seccs").show();
				$(".n_error2").hide();	
		      $('#form').unbind('submit').submit();//renable submit
			}else{
				$(".n_error2").show();
				$(".n_seccs").hide();							
			}
        }
    });
});
});
</script>



<script type="text/javascript">
$(document).ready(function() {    
$('#bank_name').change(function() {
var bank_id=$("#bank_name").val();
var data={bank_id:bank_id};
//alert(bank_id);
$.ajax({
        url: 'select_account_number',
        type: 'POST',
        dataType: 'json',
        data:data,
        success: function( data ) {
	//alert(data);
            $("#account_number").show();
$("#acc_num").val(data);
		}
    });


   });
});
</script>



</body>
</html>