<?php
ob_start();
include('opendb.inc');
$pincode=$_POST['pincode'];
$repincode=$_POST['repincode'];
if($pincode==$repincode){
$exist='1';
}
else{
$exist='0';	
}
echo json_encode($exist);
include('closedb.inc');
ob_flush();
?>
