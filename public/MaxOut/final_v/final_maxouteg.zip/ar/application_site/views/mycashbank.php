 <?php
if(!isset($_SESSION['username_admin'])||$_SESSION['username_admin']==""){
$dd=base_url();
header("Location:$dd"); 
}
else{
 $username_admin=$_SESSION['username_admin'];
 $id_useradmin=$_SESSION['id_useradmin'];
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Account | MaxOut</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <?php include("home/inc/head2.inc");?>
    </head><!--/head-->
   
<?php
include("config/opendb.inc");
$sql="select logo from site_info";
$resd=mysql_query($sql);
$row=mysql_fetch_array($resd);
$img=$row['logo'];


$sqlc="select activation from client where id='$id_useradmin'";
$resdc=mysql_query($sqlc);
$rowc=mysql_fetch_array($resdc);
$activation_code=$rowc['activation'];


$sql_active="select active_account,price_activeaccount from network_seting";
$res_active=mysql_query($sql_active);
$row_Active=mysql_fetch_array($res_active);
$active_account=$row_Active['active_account'];
$price_activeaccount=$row_Active['price_activeaccount'];

//echo $active_account;

if($active_account==1&&$activation_code==0){
	$show="block";
	}
	else {
		$show="none";
		}
		


$sqlcash="select SUM(cash_money) as cash_money from cash_type where customer_id='$id_useradmin' and type='get' and view='1' ";
$resdcash=mysql_query($sqlcash);
$rowcash=mysql_fetch_array($resdcash);
$cashmoney_get=$rowcash['cash_money'];
//echo $cashmoney_get;

$sqlpost="select SUM(cash_money) as cash_money from cash_type where customer_id='$id_useradmin' and type='post' and view='1' ";
$resdpost=mysql_query($sqlpost);
$rowpost=mysql_fetch_array($resdpost);
$cashmoney_post=$rowpost['cash_money'];
$total_cash=$cashmoney_get-$cashmoney_post;

		if($total_cash<100){
		$show_total="none";
		$show_nototal="block";	
		}
		else {
    $show_total="block";
		$show_nototal="none";	
		}
			
$r=$_GET['r'];
$page=$_GET['page'];
$per_page =10; 
if($page==""){
	$page=1;
}

$sql="";
	
?>

</head><!--/head-->

<body>
	<?php include("home/inc/header.inc");?><!--/header-->

	<section>
		<div class="container">
			<div class="row">
						<div class="col-sm-3">
					<div class="left-sidebar">
                        <div class="shipping text-center"><!--user-profile-->
                            <h2 class="username"><?php echo $username_admin?></h2>
                             <img src="<?php echo base_url()?><?php echo $image_client?>" alt="" />
                            <script type="text/javascript">
                            function performClick(elemId) {
                               var elem = document.getElementById(elemId);
                               if(elem && document.createEvent) {
                                  var evt = document.createEvent("MouseEvents");
                                  evt.initEvent("click", true, false);
                                  elem.dispatchEvent(evt);
                               }
                            }
                            </script>
                            <a href="#" onclick="performClick('theFile');" class="change-img" title="Change Picture"><i class="fa fa-camera" aria-hidden="true"></i></a>
                            <input type="file" id="theFile" style="display:none;"/>
						</div><!--/user-profile-->


						<h2>FAVOURITES</h2>
						<!--/user-favourites-->

<?php include("home/inc/favorite.inc");?>

					</div>
				</div>

				<div class="col-sm-9 padding-right">
					<div class="features_items"><!--features_items-->
						<h2 class="title text-center">My Cash Bank</h2>

                        <div class="col-sm-12">
                         <div class="alert alert-warning"  id="alert-warning" style="text-align:center;display:<?php echo $show_nototal?>;;width: 100%;  z-index: 1000;"> <strong style="margin-right:10px;">Warning!</strong>Your Cash bank less than or eqaul 100 ,you can not any Processes on your account.
                                </div>
							<div class="Plan-By-Date cash-bank" >
                            <div >
                                <h4 style="display:<?php echo $show_total?>">Cash Bank : <span><?php echo $total_cash;?></span></h4>
                                <span class="active-account" style="display:<?php echo $show?>; margin:10px 0; float:right;">
                                    Active My Account With <?php echo $price_activeaccount;?>
                                    <a class="btn" href="client_active">Active</a>
                                </span>
                                </div>
                                <table>
                                    <thead>
                                    	<tr>
                                        	<th scope="col">index</th>
                                            <th scope="col">Commission</th>
                                            <th scope="col">Date</th>
                                            <th scope="col">Check</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                      <?php
						  $id="";
						  $name="";
						  $counter=0;
						  
						  /*first user in page*/
                          $start = ($page-1)*$per_page;
						  $sql = "SELECT SQL_CALC_FOUND_ROWS * from cash_type where type='get' and comtiontype='offline' and customer_id='$id_useradmin' order by id desc limit $start,$per_page";
						  $rsd=mysql_query($sql) or die(mysql_error());
						  
						  /*count all alarms*/
						  if($r=="")
						  { 
						    $all_sql="SELECT FOUND_ROWS()";
                            $all = mysql_query($all_sql);
		                    $row2 = mysql_fetch_array($all);
    	                    $count=$row2[0];	
                          }
                          else{
	                        $count=$r;
                          }
        
		                  /*all pages*/
                          $pages = ceil($count/$per_page);
						  /*pages in pagination*/
						  $pages_in =10;
						  /*start_pagination and end_pagination*/
                          $start_page = ((ceil($page/$pages_in)-1)*$pages_in)+1;
                          if(($start_page+$pages_in-1)>$pages){
							 $end_page=$pages;
                          }
                          else{
                             $end_page=$start_page+9;
                          }
						  if(mysql_num_rows($rsd)==0){
						?>
                         <tr style="height:100px">
                          <td colspan="10" class="center" style="color:#E63998; font-size:18px">
                     <?php echo $exite?>
                          </td>
                        </tr>
                        <?php
						  }
						  while($row=mysql_fetch_assoc($rsd)){
							  $id_categ=$row['id'];
							     $cash_money=$row['cash_money']; 
								$comtiontype=$row['comtiontype'];
								$counter++;
						       $view=$row['view'];
							  switch($view){
								  case 0:
								    $view="<span class='view' style='color:red'>$no_activite</span>";
								    break;
								  case 1:
								    $view="<span class='view' style='color:green'>$activite</span>";
								    break;
								  default:
								    break; 
							  }
							 $date=date("Y-m-d h:m",strtotime($row['date']));
						?>

                                        <tr>
                                          	<td><?php echo $counter?></td>
                                          	<td><?php echo $cash_money?> LE</td>
                                            <td><?php echo $date?></td>
                                            <td><div class="show-network"><a href="check/<?php echo $id_categ;?>" target="_blank">Check</a></div></td>
                                        </tr>

                                      
<?php }?>

                                    </tbody>
                                </table>
                               

 <?php
                if($pages==1)
				{
					echo '<div class="pagination">
	    		           <span class="active">[1]</span>
			              </div>';
				}else if($pages>1){
					echo '<div class="pagination">';
			        if($page!=1){
					  $pr_page=$page-1;
					  echo '<a href="mycashbank?r='.$count.'&page='.$pr_page.'">«'.$prev.'</a>';							  
					}else{
						echo '<span>«'.$prev.'</span>';
					}
					
					for($i=$start_page;$i<=$end_page;$i++){
						if($i==$page){
							echo '<span class="active">'.$i.'</span>';
						}
						else{
							echo '<a href="mycashbank?r='.$count.'&page='.$i.'">'.$i.'</a>';
						}
					}
					
					if($page!=$pages){
						$nx_page=$page+1;
						echo '<a href="mycashbank?r='.$count.'&page='.$nx_page.'">'.$next.'»</a>';	
					}else{
						echo '<span>'.$next.'»</span>';
					}
                           
	    		    echo '</div>';
				}
				?>
               <div class="sep"></div>
              


							</div>
						</div>
						
					</div><!--features_items-->


				</div>
			</div>
		</div>
	</section>
	
	<footer id="footer"><!--Footer-->
		<div class="footer-top">
			<div class="container">
				<div class="row">
					<div class="col-sm-2">
						<div class="companyinfo">
							<h2><span>MAX</span>OUT</h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit,sed do eiusmod tempor</p>
						</div>
					</div>
					<div class="col-sm-7">
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="../home/images/home/iframe1.png" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								<p>Circle of Hands</p>
								<h2>24 DEC 2014</h2>
							</div>
						</div>
						
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="../home/images/home/iframe2.png" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								<p>Circle of Hands</p>
								<h2>24 DEC 2014</h2>
							</div>
						</div>
						
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="../home/images/home/iframe3.png" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								<p>Circle of Hands</p>
								<h2>24 DEC 2014</h2>
							</div>
						</div>
						
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="../home/images/home/iframe4.png" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								<p>Circle of Hands</p>
								<h2>24 DEC 2014</h2>
							</div>
						</div>
					</div>
					<div class="col-sm-3">
						<div class="address">
							<img src="../home/images/home/map.png" alt="" />
							<p>505 S Atlantic Ave Virginia Beach, VA(Virginia)</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="footer-widget">
			<div class="container">
				<div class="row">
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>Service</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="#">Online Help</a></li>
								<li><a href="#">Contact Us</a></li>
								<li><a href="#">Order Status</a></li>
								<li><a href="#">Change Location</a></li>
								<li><a href="#">FAQ’s</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>Quock Shop</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="#">T-Shirt</a></li>
								<li><a href="#">Mens</a></li>
								<li><a href="#">Womens</a></li>
								<li><a href="#">Gift Cards</a></li>
								<li><a href="#">Shoes</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>Policies</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="#">Terms of Use</a></li>
								<li><a href="#">Privecy Policy</a></li>
								<li><a href="#">Refund Policy</a></li>
								<li><a href="#">Billing System</a></li>
								<li><a href="#">Ticket System</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>About Shopper</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="#">Company Information</a></li>
								<li><a href="#">Careers</a></li>
								<li><a href="#">Store Location</a></li>
								<li><a href="#">Affillate Program</a></li>
								<li><a href="#">Copyright</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-3 col-sm-offset-1">
						<div class="single-widget">
							<h2>About Shopper</h2>
							<form action="#" class="searchform">
								<input type="text" placeholder="Your email address" />
								<button type="submit" class="btn btn-default"><i class="fa fa-arrow-circle-o-right"></i></button>
								<p>Get the most recent updates from <br />our site and be updated your self...</p>
							</form>
						</div>
					</div>
					
				</div>
			</div>
		</div>
		
		<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<p class="pull-left">Copyright © 2016 MaxOut. All rights reserved.</p>
					<p class="pull-right">Designed by <span><a target="_blank" href="http://www.tech4life.com">Tech4Life</a></span></p>
				</div>
			</div>
		</div>
		
	</footer><!--/Footer-->
	
<?php include("home/inc/headf2.inc");?>

</body>
</html>