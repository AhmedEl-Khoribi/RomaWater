<?php
ob_start();
include('opendb.inc');
$usercode=$_POST['usercode'];

$sql="select * from client where usercode='$usercode'";
$resd=mysql_query($sql) or die("".mysql_error());
$counss=mysql_num_rows(mysql_query($sql));
if($counss>0){
$exist='1';
}
else{
$exist='0';	
}
echo json_encode($exist);
include('closedb.inc');
ob_flush();
?>
