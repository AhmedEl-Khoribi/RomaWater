<?php
ob_start();
  $dd=base_url();
include('opendb.inc');
$password=$_POST['password'];
$pincode=$_POST['pincode'];
$fname=$_POST['fname'];
$sname=$_POST['sname'];
$lname=$_POST['lname'];
$uname=$_POST['uname'];
$nationalid=$_POST['nationalid'];
$datebrith=$_POST['datebrith'];
$state=$_POST['state'];
$city=$_POST['city'];
$address=$_POST['address'];
$phone=$_POST['phone'];
$id=$_POST['id'];

$coun=mysql_num_rows(mysql_query("select * from client where username='$uname'"));


$sqlv="select changedate_value from network_seting ";
$resv=mysql_query($sqlv) or die("".mysql_error());
$rowv=mysql_fetch_array($resv);
$changedate_value =$rowv['changedate_value'];
echo $changedate_value;

$sqlcash="select SUM(cash_money) as cash_money from cash_type where customer_id='$id' and type='get' and view='1'";
$resdcash=mysql_query($sqlcash);
$rowcash=mysql_fetch_array($resdcash);
$cashmoney_get=$rowcash['cash_money'];
//echo $cashmoney_get;

$sqlpost="select SUM(cash_money) as cash_money from cash_type where customer_id='$id' and type='post' and view='1'";
$resdpost=mysql_query($sqlpost);
$rowpost=mysql_fetch_array($resdpost);
$cashmoney_post=$rowpost['cash_money'];
$total_cash=$cashmoney_get-$cashmoney_post;
echo $total_cash;



if($total_cash>$changedate_value&&$coun==0){
	
	$_SESSION['username_admin']=$uname;
$update="insert into cash_type (cash_money,customer_id,type,comtiontype,client_sender,view) values('$changedate_value','$id','post','ChangeData','$id','1')";
	$mysqll=mysql_query($update);


$sql="update client set fname='$fname',sname='$sname',lname='$lname',phone='$phone',username='$uname',Nationaid='$nationalid',dateofbirth='$datebrith',address='$address',state='$state',city='$city' where id='$id'";
$rsd=mysql_query($sql) or die("".mysql_error());
header("location:$dd/homepage/profile");
}

else {
header("location:$dd/homepage/changedata?error");
}
//$_SESSION['username_admin']=$username;
include('closedb.inc');
//
?>
