<?php
include('opendb.inc');
$name_ar=$_POST['name_ar'];
$name_eng=$_POST['name_eng'];
$keywords=$_POST['keywords'];
$metadesc=$_POST['metadesc'];

$sql="update site_info set name='$name_eng',name_ar='$name_ar',keywords='$keywords',description='$metadesc'";
$rsd=mysql_query($sql) or die("".mysql_error());

function gen_random_string()
{
    $chars ="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";//length:36
    $final_rand='';
    for($i=0;$i<4; $i++)
    {
        $final_rand .= $chars[ rand(0,strlen($chars)-1)];
    }
    return $final_rand;
}

if($_FILES["file"]["name"]!=""){
$url=$_FILES["file"]["name"];
//$url=$_GET['file'];
echo $url;
$parts=explode('.',$url);
$lenght=count($parts);
$curr_page=$parts[$lenght-1];
$img_name=gen_random_string().".".$curr_page;
copy($_FILES["file"]["tmp_name"], "../images/" . $_FILES["file"]["name"]);
rename("../images/$url","../images/$img_name");
$sql="update site_info set logo='$img_name'";
$rsd=mysql_query($sql);

}
include('closedb.inc');
header("location:../home/setting");
?>
