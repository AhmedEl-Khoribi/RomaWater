<?php
//ob_start();
include('opendb.inc');
$bank_id=$_POST['bank_id'];

$sql = "select num from  bank_account where id='$bank_id'";
$res=mysql_query($sql);
$row=mysql_fetch_array($res);
$account_num=$row['num'];

include('closedb.inc');
echo json_encode($account_num);
ob_flush();
?>
