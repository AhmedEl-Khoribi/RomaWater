<?php
include("config/opendb.inc");
ob_start();
if(!isset($_SESSION['username_admin'])||$_SESSION['username_admin']==""){
header("Location:http://maxouteg.com/new/"); 
}
else{
 $username_admin=$_SESSION['username_admin'];
 $id_useradmin=$_SESSION['id_useradmin'];
}

$success="رسالة النجاح! إعدادات تم حفظها في قاعدة البيانات";
$error="رسالة خطأ! كان هناك خطأ في البيانات المدرجة، أو أن هناك بيانات ناقصة";
if(isset($_GET['mess'])){
$df="block";
}
else{
$df="none";	
}
?>

<!DOCTYPE html>



<!--[if !IE]><!--><html class="sidebar sidebar-discover"><!-- <![endif]-->

<head>

	<title>ارسال رسالة</title>



	<meta charset="utf-8">
<?php 
	include ("home/inc/head1.inc");
	?>
<script src="assets/js/jquery-1.9.1.min.js"></script>
	<script src="text_js/ckeditor.js"></script>
<link href="text_css/sample.css" rel="stylesheet">
</head>

<body class="">

	

	<!-- Main Container Fluid -->

	<div class="container-fluid menu-hidden">

	

<?php 

include ("home/inc/sidebar1.inc");

?>





			

		</div>

		<!-- // Sidebar Menu END -->

				

		<!-- Content -->

		<div id="content">



<?php 

include("home/inc/header.inc");

?>		
<div class="innerLR">

	<!-- Widget -->
	<div class="widget-body innerAll">
<div class="n_ok" style="display:<?php echo $df;?>; direction:rtl; font-family:NeoSansArabic !important"><p><?php echo $success?></p></div>
                <div class="n_error" style="display:none"><p><?php echo $error?></p></div>
				<div class="innerLR">
	<!-- Form -->
<form  method="post" action="compsedmessage" id="myform"  >
<input type="hidden" name="type" value="0">
	<!-- Widget -->
	<div class="widget">

<div class="widget-body innerAll inner-2x">
		
			<!-- Row -->
			<div class="row innerLR"  >
			
<div class="form-group"  style="width:100%">
<label class=""  style="direction:rtl;font-family:NeoSansArabic; float:right">المرسل اليه</label>
<input   name="reciver" type="text"   style="width:100%;font-family:NeoSansArabic;direction:rtl; height:40px;"  placeholder="اسم المستخدم"   required/></div>
</div>
<div class="form-group"  style="width:100%">
<label class=""  style="direction:rtl;font-family:NeoSansArabic; float:right"><span style="float:right; line-height:30px;">ارسال الى الكل</span>
<span style="float:right">
<input   name="forall" type="checkbox"   style="width:50px;font-family:NeoSansArabic;direction:rtl; height:25px;"  value="1"/></span></label></div>
</div>
<div class="col-md-4" style="width:100%; direction:ltr" align="center" >
					<div class="form-group">
						<label class="control-label" for="firstname" style=" direction:rtl; float:right;font-family:NeoSansArabic !important">الموضوع</label>
                        <input class="form-control" id="firstname" name="Subject" type="text" style="width:100%; text-align:right; direction:rtl;"/></div>
	
				</div>
                
                         <div style="width:100%; margin-bottom:30px;" align="center">
                        <div >
						<label for="logo" style="direction:rtl;font-family:NeoSansArabic !important">الرسالة</label>
			<textarea name="mapar" rows="2" style="direction:rtl; width:100%; direction:rtl"><?php echo $details_cat;?></textarea>
                        </div>
                        </div>
                              
			</div>

			<!-- Form actions -->
			<div class="form-actions" align="center" style="padding-bottom:20px;">
             <input type="submit" value="ارسالة" class="btn btn-primary fa fa-check-circle" id="Send"  style="font-family:NeoSansArabic !important">
			</div>
			<!-- // Form actions END -->
			
		</div>
	</div>
	<!-- // Widget END -->
	
</form>
<!-- // Form END -->			</div>
			
			
		</div>
</div>
	
	
		
		</div>
	</div>
    <div style=" clear:both; height:20px;"></div>
<div class="clearfix">
<script>			
			CKEDITOR.replace( 'mapar');
			CKEDITOR.replace( 'mapeng');
		</script>
</div>
<div id="footer" class="hidden-print">

			<?php

            include ("home/inc/footer.inc");

			?>

		

		</div>

		

		<!-- // Footer END -->

		

	</div>

	<!-- // Main Container Fluid END -->

	<?php

    include ("home/inc/headf1.inc");

	?>
</body>
</html>