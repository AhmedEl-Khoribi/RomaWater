<?php
$dd=base_url();
class SendMessage {
  function sender($fromName, $from, $subject, $message, $toName, $to){  
     include("PHPMailer/class.phpmailer.php");
  
     $mail = new PHPMailer();
	 $mail->CharSet  = "utf-8";
	 $mail->From     = $from;            //print_r($from);
	 $mail->FromName = $fromName;
	  
	 $mail->IsSMTP();
	  
	 $mail->SMTPAuth = true;     // turn of SMTP authentication
     $mail->Username = "test@cnt-e.com";  // SMTP username
	 $mail->Password = "HnU&+Kha.N[&"; // SMTP password
	 $mail->SMTPSecure = "ssl";              // for gmail
	 //$mail->Host = "smtp.mail.yahoo.com";  // for yahoo
	 //$mail->Port = 587;                    // yahoo port
	 $mail->Host = "nova.websitewelcome.com";         // for gmail
	 $mail->Port = 465;                      // for gmail
    $mail->SMTPDebug  = 2; // Enables SMTP debug information (for testing, remove this line on production mode)
	 // 1 = errors and messages
	 // 2 = messages only
	   
	 //$mail->Sender   =  "EMAIL ADDRESS TO RECIEVE BOUNCES";// $bounce_email;
	 $mail->ConfirmReadingTo  = "EMAIL ADDRESS TO GET READING REPORT";
	  
	 $mail->AddReplyTo($from,$fromName);
	 $mail->IsHTML(true); //turn on to send html email
	 $mail->Subject = $subject;
	 
	 $mail->Body     =  $message;
	 $mail->AltBody  =  $message;
	  
	 $mail->AddAddress($to,$toName);
	        
	 if($mail->Send()){
	  $mail->ClearAddresses();
	   return "success";  
	 }
  }
}
?>

<?php
ob_start();
include('opendb.inc');
$reciver=$_POST['reciver'];
$forall=$_POST['forall'];
$type=$_POST['type'];
$Subject=$_POST['Subject'];
$message=$_POST['mapar'];

$sqll="select id ,mail from client where username='$reciver'";
$rsdd=mysql_query($sqll);
$row=mysql_fetch_array($rsdd);
$client_recevier_id=$row['id'];
$mail=$row['mail'];
echo $mail;
$sql = "INSERT INTO client_message 
(client_sender_id,client_recevier_id,subject,message,type)
 VALUES('1','$client_recevier_id','$Subject','$message','$type')";
 $rsd= mysql_query($sql) or die(mysql_error());



$code_source="<p style='font-weight:bold;font-size:16px;font-family:Verdana, Geneva, sans-serif;' align='center'>لديك رسالة خاصة من موقع ماكس اوت
للمتابعة <a href='#'>اضغط هنا</a> </p>";
		$send = new SendMessage();
		$send->sender("MaxOut", "ashraf.mohammed92@gmail.com", "تنبيه من موقع ماكس اوت", "$code_source", "$reciver", "$mail");


include('closedb.inc');
header("location:".$dd."home/composed?mess=success");
ob_flush();
?>