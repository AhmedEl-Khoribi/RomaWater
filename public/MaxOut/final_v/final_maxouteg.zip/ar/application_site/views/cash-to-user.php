 <?php
 $dd=base_url();
if(!isset($_SESSION['username_admin'])||$_SESSION['username_admin']==""){
header("Location:$dd"); 
}
else{
 $username_admin=$_SESSION['username_admin'];
 $id_useradmin=$_SESSION['id_useradmin'];
}
?>

<?php
 if(isset($_GET['up'])){
	$showw="block";
	}
	else{
	$showw="none";	
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Transfer Cash To User| MaxOut</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <?php include("home/inc/head2.inc");?>
    </head><!--/head-->
   
<?php
include("config/opendb.inc");
$sql="select logo from site_info";
$resd=mysql_query($sql);
$row=mysql_fetch_array($resd);
$img=$row['logo'];


$sqlc="select activation from client where id='$id_useradmin'";
$resdc=mysql_query($sqlc);
$rowc=mysql_fetch_array($resdc);
$activation_code=$rowc['activation'];

foreach($netinfo as $row)
$active_account=$row->active_account;
$price_activeaccount=$row->price_activeaccount;
if($active_account==1&&$activation_code==0){
	$show="block";
	}
	else {
		$show="none";
		}
		


$sqlcash="select SUM(cash_money) as cash_money from cash_type where customer_id='$id_useradmin' and type='get' and view='1' ";
$resdcash=mysql_query($sqlcash);
$rowcash=mysql_fetch_array($resdcash);
$cashmoney_get=$rowcash['cash_money'];
//echo $cashmoney_get;

$sqlpost="select SUM(cash_money) as cash_money from cash_type where customer_id='$id_useradmin' and type='post' and view='1' ";
$resdpost=mysql_query($sqlpost);
$rowpost=mysql_fetch_array($resdpost);
$cashmoney_post=$rowpost['cash_money'];
$total_cash=$cashmoney_get-$cashmoney_post;

if($total_cash<=0){
		$show_total="none";
		$show_nototal="block";	
		}
		else {
    $show_total="block";
		$show_nototal="none";	
		}

if(isset($_GET['success'])){
	$show="block";
	$show1="none";
	}
	else if(isset($_GET['error'])){
	$show1="block";
	$show="none";
	}
	else{
	$show="none";
	$show1="none";	
	}
?>

</head><!--/head-->

<body>
	<?php include("home/inc/header.inc");?><!--/header-->

	<section>
		<div class="container">
			<div class="row">
				<div class="row">
								<div class="col-sm-3">
					<div class="left-sidebar">
                        <div class="shipping text-center"><!--user-profile-->
                            <h2 class="username"><?php echo $username_admin?></h2>
                            <img src="<?php echo base_url()?><?php echo $image_client?>" alt="" />
                            <script type="text/javascript">
                            function performClick(elemId) {
                               var elem = document.getElementById(elemId);
                               if(elem && document.createEvent) {
                                  var evt = document.createEvent("MouseEvents");
                                  evt.initEvent("click", true, false);
                                  elem.dispatchEvent(evt);
                               }
                            }
                            </script>
                            <a href="#" onclick="performClick('theFile');" class="change-img" title="Change Picture"><i class="fa fa-camera" aria-hidden="true"></i></a>
                            <input type="file" id="theFile" style="display:none;"/>
						</div><!--/user-profile-->


						<h2>FAVOURITES</h2>
						<!--/user-favourites-->

<?php include("home/inc/favorite.inc");?>

					</div>
				</div>

				<div class="col-sm-9 padding-right">
					<div class="features_items"><!--features_items-->
						<h2 class="title text-center">Transfer Cash To User</h2>

                        <div class="col-sm-12">
                          <div class="alert alert-success"  id="alert-success" style="text-align:center;display:<?php echo $show?>;position: fixed;width: 300px; top:140px; right:120px; z-index: 1000;"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                                    <strong style="margin-right:10px;">Success!</strong>Saved Your Data.
                                </div>
 <div class="alert alert-danger"  id="alert-danger" style="text-align:center;display:<?php echo $show1?>;position: fixed;width: 300px; top:140px; right:120px; z-index: 1000;"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                                    <strong style="margin-right:10px;">Error!</strong>there is error in your data.
                                </div>
                                
                         <div class="alert alert-warning"  id="alert-warning" style="text-align:center;display:<?php echo $show_nototal?>;;width: 100%;  z-index: 1000;"> <strong style="margin-right:10px;">Warning!</strong>Your Cash bank now zero,you can not any Processes on your account.
                                </div>
                                
                                 <div class="alert alert-danger"  id="all_error" style="text-align:center;display:none;">
                                    <strong style="margin-right:10px;">Error!</strong>there is error in your data.
                                </div>
                                
							<div class="cash-bank account" style="display:<?php echo $show_total?>">
                                <h4>Cash Bank : <span><?php echo $total_cash;?></span></h4>
                                <h4 style="font-size:16px; display:<?php echo $showw?>">The Transfer Cash has been successfully</h4>
                                                               
  <form action="cashbanktouser" for="#useraccount" method="post" id="form">
  <input type="hidden" value="<?php echo $id_useradmin?>" name="id">
                                   <div>
                                    <label>Username:</label>
                                    
                        		   <input type="text" placeholder="Username" id="username"  name="username" required/>
                                    <span class="n_error0" style="font-size:14px; color:#F00; display:none">Sorry,This User Name incorrect</span>
                                    </div>
                                    <div>
                                    <label>User Code:</label>
                        			<input type="text" placeholder="User Code" name="usercode" required id="usercode" />
                                     <span class="n_error1" style="font-size:14px; color:#F00; display:none">Sorry, User Code incorrect</span>
                                    </div>
                                    <div>
                                    <label>Cash</label>
                        			<input type="number" placeholder="Cash" name="cash" required id="cash"/></div>
                                    <div>
                                    <label>Pin Code</label>
                        			<input type="text" placeholder="Pin Code" name="pincode"  id="pincode" required/>
                                     <span class="n_error2" style="font-size:14px; color:#F00; display:none">Sorry, PinCode incorrect</span>
                                    </div>
                                    <!--<label> Captcha</label>
                        			<input type="text" placeholder="captcha" required />
                                    <img src="images/Captcha/Captcha-Header.png" alt="" />-->
                                    <button type="submit" class="btn" id="btn">Transfer</button>

                        		</form>                              

 
 
                <div class="sep"></div>
              


							</div>
						</div>
						
					</div><!--features_items-->


				</div>
			</div>
		</div>
	</section>
	
	<footer id="footer"><!--Footer-->
		<div class="footer-top">
			<div class="container">
				<div class="row">
					<div class="col-sm-2">
						<div class="companyinfo">
							<h2><span>MAX</span>OUT</h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit,sed do eiusmod tempor</p>
						</div>
					</div>
					<div class="col-sm-7">
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="../home/images/home/iframe1.png" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								<p>Circle of Hands</p>
								<h2>24 DEC 2014</h2>
							</div>
						</div>
						
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="../home/images/home/iframe2.png" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								<p>Circle of Hands</p>
								<h2>24 DEC 2014</h2>
							</div>
						</div>
						
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="../home/images/home/iframe3.png" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								<p>Circle of Hands</p>
								<h2>24 DEC 2014</h2>
							</div>
						</div>
						
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="../home/images/home/iframe4.png" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								<p>Circle of Hands</p>
								<h2>24 DEC 2014</h2>
							</div>
						</div>
					</div>
					<div class="col-sm-3">
						<div class="address">
							<img src="../home/images/home/map.png" alt="" />
							<p>505 S Atlantic Ave Virginia Beach, VA(Virginia)</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="footer-widget">
			<div class="container">
				<div class="row">
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>Service</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="#">Online Help</a></li>
								<li><a href="#">Contact Us</a></li>
								<li><a href="#">Order Status</a></li>
								<li><a href="#">Change Location</a></li>
								<li><a href="#">FAQ’s</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>Quock Shop</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="#">T-Shirt</a></li>
								<li><a href="#">Mens</a></li>
								<li><a href="#">Womens</a></li>
								<li><a href="#">Gift Cards</a></li>
								<li><a href="#">Shoes</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>Policies</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="#">Terms of Use</a></li>
								<li><a href="#">Privecy Policy</a></li>
								<li><a href="#">Refund Policy</a></li>
								<li><a href="#">Billing System</a></li>
								<li><a href="#">Ticket System</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>About Shopper</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="#">Company Information</a></li>
								<li><a href="#">Careers</a></li>
								<li><a href="#">Store Location</a></li>
								<li><a href="#">Affillate Program</a></li>
								<li><a href="#">Copyright</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-3 col-sm-offset-1">
						<div class="single-widget">
							<h2>About Shopper</h2>
							<form action="#" class="searchform">
								<input type="text" placeholder="Your email address" />
								<button type="submit" class="btn btn-default"><i class="fa fa-arrow-circle-o-right"></i></button>
								<p>Get the most recent updates from <br />our site and be updated your self...</p>
							</form>
						</div>
					</div>
					
				</div>
			</div>
		</div>
		
		<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<p class="pull-left">Copyright © 2016 MaxOut. All rights reserved.</p>
					<p class="pull-right">Designed by <span><a target="_blank" href="http://www.tech4life.com">Tech4Life</a></span></p>
				</div>
			</div>
		</div>
		
	</footer><!--/Footer-->
	
<?php include("home/inc/headf2.inc");?>

<script type="text/javascript">
$(document).ready(function(e) {    
$('#usercode').click(function(e){
	    $(".n_error").hide();
		e.preventDefault();
		var username=$("#username").val();
		var data={username:username};
    $.ajax({
        url: 'checkusername',
        type: 'POST',
        dataType: 'json',
        data:data,
        success: function( data ) {
			//alert(data);
            if(data==1){
				$(".n_seccs").show();
				$(".n_error0").hide();	
		     // $('#form').unbind('submit').submit();//renable submit
			}else{
				$(".n_error0").show();
				$(".n_seccs").hide();							
			}
        }
    });
});
});
</script>



<script type="text/javascript">
$(document).ready(function(e) {    
$('#cash').click(function(e){
	    $(".n_error").hide();
		e.preventDefault();
		var usercode=$("#usercode").val();
		var data={usercode:usercode};
    $.ajax({
        url: 'checkusercode',
        type: 'POST',
        dataType: 'json',
        data:data,
        success: function( data ) {
			//alert(data);
            if(data==1){
				$(".n_seccs").show();
				$(".n_error1").hide();	
		      //$('#form').unbind('submit').submit();//renable submit
			}else{
				$(".n_error1").show();
				$(".n_seccs").hide();							
			}
        }
    });
});
});
</script>


<script type="text/javascript">
$(document).ready(function(e) {    
$('#btn').click(function(e){
	    $(".n_error").hide();
		e.preventDefault();
		var data=$("#form").serialize();
    $.ajax({
        url: 'check_alldata',
        type: 'POST',
        dataType: 'json',
        data:data,
        success: function( data ) {
			//alert(data);
            if(data==1){
				$(".n_seccs").show();
				$("#all_error").hide();	
		      $('#form').unbind('submit').submit();//renable submit
			}else{
				$("#all_error").show();
				$(".n_seccs").hide();							
			}
        }
    });
});
});
</script>


</body>
</html>