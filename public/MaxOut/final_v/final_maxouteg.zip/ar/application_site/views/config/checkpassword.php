<?php
ob_start();
include('opendb.inc');
$username=$_POST['username'];
$password=$_POST['password'];
$sql="select * from client where username='$username'and password='$password'";
$resd=mysql_query($sql) or die("".mysql_error());
$row=mysql_fetch_array($resd);
//echo $row['id'];
$counss=mysql_num_rows(mysql_query($sql));
//echo $counss;
if($counss>0){
	$_SESSION['username_admin']=$row['username'];
	$_SESSION['last_login']=$row['last_login'];
	$_SESSION['id_useradmin']=$row['id'];
	$_SESSION['counter']=1;
 $username_admin=$_SESSION['username_admin'];
$sql="UPDATE client SET last_login=NOW() WHERE username='$username_admin'";
$fed=mysql_query($sql);
$exist='1';
}
else{
$exist='0';	
}
echo json_encode($exist);
include('closedb.inc');
ob_flush();
?>
