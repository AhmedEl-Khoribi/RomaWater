<?php
ob_start();
include('opendb.inc');
$pincode=$_POST['pincode'];
$usercode=$_POST['usercode'];
$username=$_POST['username'];
$cash=$_POST['cash'];
$id_useradmin=$_POST['id'];
$sql="select * from client where usercode='$usercode' and username='$username'";
$resd=mysql_query($sql) or die("".mysql_error());

$counss=mysql_num_rows(mysql_query($sql));

$coun=mysql_num_rows(mysql_query("select * from client where pincode='$pincode' and id='$id_useradmin'"));

if($counss==1&&$cash>0&&$coun==1){
$exist='1';
}
else{
$exist='0';	
}
echo json_encode($exist);
include('closedb.inc');
ob_flush();
?>
