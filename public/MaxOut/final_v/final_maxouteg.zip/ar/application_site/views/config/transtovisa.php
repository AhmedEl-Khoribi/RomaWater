<?php
ob_start();
include('opendb.inc');
$bankname=$_POST['bankname'];
$banknumber=$_POST['banknumber'];
$bankowner=$_POST['bankowner'];
$cash=$_POST['cash'];
$pincode=$_POST['pincode'];
$id=$_POST['id'];

$sqlcash="select SUM(cash_money) as cash_money from cash_type where customer_id='$id' and type='get' and view='1' ";
$resdcash=mysql_query($sqlcash);
$rowcash=mysql_fetch_array($resdcash);
$cashmoney_get=$rowcash['cash_money'];

$sqlpost="select SUM(cash_money) as cash_money from cash_type where customer_id='$id' and type='post' and view='1' ";
$resdpost=mysql_query($sqlpost);
$rowpost=mysql_fetch_array($resdpost);
$cashmoney_post=$rowpost['cash_money'];
$total_cash=$cashmoney_get-$cashmoney_post;
if($total_cash>$cash){
$sql = "INSERT INTO cash_type 
(cash_money,customer_id,comtiontype,client_sender,type,view)
 VALUES('$cash','$id','transfertovisa','$id','post','0')";
$rsd= mysql_query($sql) or die(mysql_error());
$cash_id=mysql_insert_id();
echo 

$sql = "INSERT INTO bank_details 
(cash_id,bank_id,acco_num,acco_name)
 VALUES('$cash_id','$bankname','$banknumber','$bankowner')";
$rsd= mysql_query($sql) or die(mysql_error());
include('closedb.inc');
header("location:cash_to_visa?success");
}
else {
header("location:cash_to_visa?error");
}


//header("location:cash_to_visa?up=1");
ob_flush();
?>
