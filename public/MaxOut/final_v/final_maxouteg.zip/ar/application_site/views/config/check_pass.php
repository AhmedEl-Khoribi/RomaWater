<?php
ob_start();
include('opendb.inc');
$pass=$_POST['pass'];
$retpass=$_POST['retpass'];
if($pass==$retpass){
$exist='1';
}
else{
$exist='0';	
}
echo json_encode($exist);
include('closedb.inc');
ob_flush();
?>
