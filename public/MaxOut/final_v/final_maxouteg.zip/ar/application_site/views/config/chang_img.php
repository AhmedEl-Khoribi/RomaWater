<?php
$dd=base_url();
ob_start();
include('opendb.inc');
$id_useradmin=$_POST['id'];

//echo $id_useradmin;
function gen_random_string()
{
    $chars ="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";//length:36
    $final_rand='';
    for($i=0;$i<4; $i++)
    {
        $final_rand .= $chars[ rand(0,strlen($chars)-1)];
    }
    return $final_rand;
}

echo $ar_name;
$url=$_FILES["file"]["name"];
echo $url;
$parts=explode('.',$url);
$lenght=count($parts);
$curr_page=$parts[$lenght-1];
$img_name=gen_random_string().".".$curr_page;
copy($_FILES["file"]["tmp_name"], "images/profile/" . $_FILES["file"]["name"]);
rename("images/profile/$url","images/profile/$img_name");

//echo $img_name;

$sql="update client set image='$img_name' where id='$id_useradmin'";
$res=mysql_query($sql) or die("".mysql_error());

include('closedb.inc');
header("Location:$dd"."homepage/profile/"); 
ob_flush();
?>
