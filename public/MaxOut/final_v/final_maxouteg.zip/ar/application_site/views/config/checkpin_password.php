<?php
ob_start();
include('opendb.inc');
$pincode=$_POST['pincode'];
$id_useradmin=$_POST['id_useradmin'];
$password=$_POST['password'];
$coun=mysql_num_rows(mysql_query("select * from client where pincode='$pincode' and  password='$password'  and id='$id_useradmin'"));
//$coun1=mysql_num_rows(mysql_query("select * from client where password='$password' and id='$id_useradmin'"));
if($coun==1){
$exist='1';
}
else{
$exist='0';	
}
echo json_encode($coun);
include('closedb.inc');
ob_flush();
?>
