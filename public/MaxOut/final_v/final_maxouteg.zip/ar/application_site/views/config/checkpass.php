<?php
ob_start();
include('opendb.inc');
$password=$_POST['password'];
$id_useradmin=$_POST['id_useradmin'];
$coun=mysql_num_rows(mysql_query("select * from client where password='$password' and id='$id_useradmin'"));
if($coun==1){
$exist='1';
}
else{
$exist='0';	
}
echo json_encode($exist);
include('closedb.inc');
ob_flush();
?>
